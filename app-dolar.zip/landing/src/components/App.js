'use strict';

import Form from './Form.js';

const App = <Form />;

ReactDOM.render(App ,  document.getElementById('App'));