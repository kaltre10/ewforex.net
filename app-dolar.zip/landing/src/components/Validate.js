'use strict';

const Validate = () => {
	return(
		<Form />
	);
}
