'use strict';

var Validate = function Validate() {
	return React.createElement(Form, null);
};