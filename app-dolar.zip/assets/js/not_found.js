import { preLoad } from './module.js';

window.addEventListener('load', () => {

	preLoad();
	
});