// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
	apiKey: "AIzaSyAlsN6CziRTd6izGtro1oTJNlbgDYFs16Q",
	authDomain: "ewforex-56a78.firebaseapp.com",
	projectId: "ewforex-56a78",
	storageBucket: "ewforex-56a78.appspot.com",
	messagingSenderId: "662975897262",
	appId: "1:662975897262:web:165000ec6ead95b0e3d73f",
	measurementId: "G-7RL136V80N"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();