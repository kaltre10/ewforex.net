'use strict';

import Form from './Form.js';

var App = React.createElement(Form, null);

ReactDOM.render(App, document.getElementById('App'));