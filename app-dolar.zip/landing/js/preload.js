document
	.addEventListener('DOMContentLoaded', 
		document
			.querySelector('.pre-loader')
			.remove())
